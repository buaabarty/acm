
/*
 * Additional script for offline functionality
 */

var tableId='problemset';
var searchContentId='search-content-id';

var first_time=true;
var rowbak = null;

function gen_rowbak()
{
	if (rowbak == null)
	{
		rowbak = new Array;
		colDataRows = document.getElementById(tableId).tBodies[0].rows;
		for (var i = 0; i < colDataRows.length; i ++) 
			rowbak.push(colDataRows[i].cloneNode(true));
	}
}

function last_prob()
{
	return document.getElementById('last-prob-id').value;
}

function jump2prob()
{
	var id=document.getElementById('jump2prob-id').value;
	if (/^[0-9]*$/.test(id))
	{
		id = parseInt(id);
		if (!(id >= 1000 && id <= last_prob()))
			alert('problem id out of range [1000,' + last_prob() + ']');
		else document.location='problem-'+id+'.html';
	}
	else alert('numbers only^ ^');
}

function searchInTable(col)
{
	var Table = document.getElementById(tableId);
	var Tbody = Table.tBodies[0];
	var colDataRows = Tbody.rows;

	var expr = document.getElementById(searchContentId).value;
	expr = new RegExp(expr, 'i');
	var n = 0;
	var fragment = document.createDocumentFragment();

	gen_rowbak();

	colDataRows = new Array;
	for (var i = 0; i < rowbak.length; i ++) 
		colDataRows.push(rowbak[i].cloneNode(true));

	for (var i = 0;  i < colDataRows.length; i ++) 
	{
		var val = colDataRows[i].cells[col].firstChild.textContent;
		if (expr.test(val)) 
		{
			if (n % 2 == 0)
				colDataRows[i].className = 'evenrow';
			else colDataRows[i].className = 'oddrow';
			fragment.appendChild(colDataRows[i]);
			n ++;
		}
	}

	while (Tbody.firstChild != null)
		Tbody.removeChild(Tbody.firstChild);
	Tbody.appendChild(fragment);
}


	
